# TensorFlow contrib framework.

Common TensorFlow utilities, mostly used by tf.contrib.layers and
tf.contrib.losses.
